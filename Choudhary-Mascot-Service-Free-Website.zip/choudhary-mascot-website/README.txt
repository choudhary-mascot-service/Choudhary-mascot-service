# Choudhary Mascot Service NCR — Free Website

This is a ready-to-publish static website.

## Free publishing
1. Create a free GitHub account.
2. Create a new public repository, e.g. `choudhary-mascot-service`.
3. Upload `index.html` and the `images` folder.
4. In repository Settings → Pages, choose the main branch and root folder.
5. GitHub will provide your free website address.

The site already includes WhatsApp and phone booking buttons for 9650291995.
